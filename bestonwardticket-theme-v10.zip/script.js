// Mobile Navigation Toggle
document.addEventListener("DOMContentLoaded", () => {
  // --- UI INTERACTION CODE ---
  const hamburger = document.querySelector(".hamburger");
  const navLinks = document.querySelector(".nav-links");

  if (hamburger && navLinks) {
    hamburger.addEventListener("click", () => {
      navLinks.classList.toggle("active");
      const icon = hamburger.querySelector("i");
      if (navLinks.classList.contains("active")) {
        icon.classList.remove("fa-bars");
        icon.classList.add("fa-times");
      } else {
        icon.classList.remove("fa-times");
        icon.classList.add("fa-bars");
      }
    });
  }

  // FAQ Accordion
  const faqItems = document.querySelectorAll(".faq-item");
  faqItems.forEach((item) => {
    const question = item.querySelector(".faq-question");
    question.addEventListener("click", () => {
      faqItems.forEach((otherItem) => {
        if (otherItem !== item) {
          otherItem.classList.remove("active");
          otherItem.querySelector(".faq-question").classList.remove("active");
        }
      });
      item.classList.toggle("active");
      question.classList.toggle("active");
    });
  });

  // Smooth Scroll
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      const targetId = this.getAttribute("href");
      if (targetId === "#") return;
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        e.preventDefault();
        if (navLinks) navLinks.classList.remove("active");
        const headerOffset = 80;
        const elementPosition = targetElement.getBoundingClientRect().top;
        const offsetPosition =
          elementPosition + window.pageYOffset - headerOffset;
        window.scrollTo({ top: offsetPosition, behavior: "smooth" });
      }
    });
  });

  // --- PAYMENT LOGIC ---

  // 1. Handle Payment Method Toggle
  const paymentRadios = document.querySelectorAll(
    'input[name="payment-method"]',
  );
  const paypalContainer = document.getElementById("paypal-button-container");
  const stripeButton = document.getElementById("stripe-button");

  function togglePaymentMethod() {
    let method = document.querySelector(
      'input[name="payment-method"]:checked',
    ).value;
    if (method === "paypal") {
      paypalContainer.style.display = "block";
      stripeButton.style.display = "none";
    } else {
      paypalContainer.style.display = "none";
      stripeButton.style.display = "block";
    }
  }

  paymentRadios.forEach((radio) => {
    radio.addEventListener("change", togglePaymentMethod);
  });

  // Initialize toggle state
  if (paypalContainer && stripeButton) {
    togglePaymentMethod();
  }

  // 2. PayPal SDK Render
  // Check if paypal object exists (loaded from script)
  if (typeof paypal !== "undefined" && paypalContainer) {
    paypal
      .Buttons({
        style: {
          layout: "vertical",
          color: "gold",
          shape: "rect",
          label: "pay",
        },
        createOrder: function (data, actions) {
          // Sent amount to PayPal
          return actions.order.create({
            purchase_units: [
              {
                amount: {
                  value: "14.00",
                },
              },
            ],
          });
        },
        onApprove: function (data, actions) {
          return actions.order.capture().then(function (details) {
            alert(
              "Transaction completed by " + details.payer.name.given_name + "!",
            );
            // TODO: Call your server to generate the ticket here
          });
        },
      })
      .render("#paypal-button-container");
  }

  // 3. Stripe Button Click
  // REPLACE WITH YOUR PUBLISHABLE KEY
  const stripe =
    typeof Stripe !== "undefined"
      ? Stripe("pk_test_TYooMQauvdEDq54NiTphI7jx")
      : null;

  if (stripeButton && stripe) {
    stripeButton.addEventListener("click", function () {
      // Disable button to prevent double click
      stripeButton.disabled = true;
      stripeButton.innerHTML =
        '<i class="fas fa-spinner fa-spin"></i> Processing...';

      // Call WordPress AJAX
      fetch(bot_vars.ajax_url + "?action=bot_create_stripe_session", {
        method: "POST",
      })
        .then(function (response) {
          return response.json();
        })
        .then(function (response) {
          if (response.success) {
            return stripe.redirectToCheckout({ sessionId: response.data.id });
          } else {
            alert("Error: " + response.data.message);
            stripeButton.disabled = false;
            stripeButton.innerHTML =
              '<i class="fas fa-lock"></i> Pay $14.00 with Card';
          }
        })
        .then(function (result) {
          if (result.error) {
            alert(result.error.message);
            stripeButton.disabled = false;
            stripeButton.innerHTML =
              '<i class="fas fa-lock"></i> Pay $14.00 with Card';
          }
        })
        .catch(function (error) {
          console.error("Error:", error);
          stripeButton.disabled = false;
          stripeButton.innerHTML =
            '<i class="fas fa-lock"></i> Pay $14.00 with Card';
        });
    });
  }
});
